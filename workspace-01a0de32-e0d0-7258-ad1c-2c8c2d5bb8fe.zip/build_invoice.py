"""
Builds the MAI AUTOS invoice template in two formats:
  - MAI_AUTOS_Invoice_Template.docx  (editable Word template)
  - MAI_AUTOS_Invoice_Template.pdf   (ready-to-send PDF)
Both are generated from the same DATA dictionary so they stay in sync.
"""

# ----------------------------------------------------------------------------
# Shared content
# ----------------------------------------------------------------------------
DATA = {
    "company": {
        "name": "MAI AUTOS",
        "tagline": "PREMIUM DEALERSHIP",
        "address": "Abuja, Nigeria",
        "phone": "[Phone Number]",
        "email": "[Email Address]",
    },
    "meta": [
        ("Invoice No.", "MA-2026-001"),
        ("Invoice Date", "[DD/MM/YYYY]"),
        ("Due Date", "[DD/MM/YYYY]"),
        ("Payment Terms", "[Due on receipt]"),
    ],
    "bill_to": [
        "[Customer / Company Name]",
        "[Street Address]",
        "[City, State]",
        "[Phone Number]",
        "[Email Address]",
    ],
    "vehicle": [
        ("Vehicle", "[Year]  [Make]  [Model]"),
        ("VIN / Chassis No.", "[VIN]"),
        ("Colour", "[Colour]"),
        ("Mileage", "[Mileage]"),
        ("Engine / Transmission", "[Engine]  /  [Transmission]"),
        ("Stock / Lot No.", "[Stock No.]"),
    ],
    "items": [
        ("Vehicle Sale \u2013 [Year] [Make] [Model]  (VIN: [VIN])", "1", "[0.00]", "[0.00]"),
        ("Delivery / Transportation", "1", "[0.00]", "[0.00]"),
        ("Documentation & Registration", "1", "[0.00]", "[0.00]"),
        ("[Other \u2013 Description]", "1", "[0.00]", "[0.00]"),
    ],
    "totals": [
        ("Subtotal", "$ [0.00]", False),
        ("Discount", "$ [0.00]", False),
        ("VAT (7.5%)", "$ [0.00]", False),
        ("TOTAL", "$ [0.00]", True),
        ("Amount Paid / Deposit", "$ [0.00]", False),
        ("BALANCE DUE", "$ [0.00]", True),
    ],
    "payment": [
        ("Bank Name", "[Bank Name]"),
        ("Account Name", "MAI AUTOS"),
        ("Account Number", "[Account Number]"),
        ("Payment Reference", "Invoice No. MA-2026-001"),
    ],
    "terms": [
        "Payment is due by the due date shown above. The vehicle will be released only after payment has been received in full.",
        "Ownership and title of the vehicle pass to the buyer only upon receipt of full payment.",
        "The vehicle is sold in its current condition unless a written warranty is provided by MAI AUTOS.",
        "The buyer should inspect the vehicle and verify the details above (including VIN and mileage) before taking delivery.",
        "Deposits are non-refundable unless otherwise agreed in writing.",
    ],
    "thanks": "Thank you for choosing MAI AUTOS.",
}

LOGO = "/home/user/logo_crop.png"
LOGO_RATIO = 624 / 407  # width / height of the cropped logo

BLACK = "000000"
DARK = "1A1A1A"
GREY = "666666"
LIGHT = "F2F2F2"
RULE = "BFBFBF"
WHITE = "FFFFFF"

# Column widths (mm) shared by both renderers
W_TOTAL = 180
W_ITEMS = [10, 95, 15, 30, 30]
W_PAY_TOT = [92, 88]          # payment details | totals block
W_TOTALS = [50, 35]           # label | value  (inside the totals block, right-aligned)
W_SIG = [75, 30, 75]


# ============================================================================
# WORD (.docx)
# ============================================================================
def build_docx(path):
    from docx import Document
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt, RGBColor

    # OOXML child-element sequences (Word is strict about these)
    TCPR_ORDER = ["w:cnfStyle", "w:tcW", "w:gridSpan", "w:hMerge", "w:vMerge",
                  "w:tcBorders", "w:shd", "w:noWrap", "w:tcMar", "w:textDirection",
                  "w:tcFitText", "w:vAlign", "w:hideMark"]
    TBLPR_ORDER = ["w:tblStyle", "w:tblpPr", "w:tblOverlap", "w:bidiVisual",
                   "w:tblStyleRowBandSize", "w:tblStyleColBandSize", "w:tblW", "w:jc",
                   "w:tblCellSpacing", "w:tblInd", "w:tblBorders", "w:shd", "w:tblLayout",
                   "w:tblCellMar", "w:tblLook"]
    RPR_ORDER = ["w:rStyle", "w:rFonts", "w:b", "w:bCs", "w:i", "w:iCs", "w:caps",
                 "w:smallCaps", "w:strike", "w:dstrike", "w:outline", "w:shadow",
                 "w:emboss", "w:imprint", "w:noProof", "w:snapToGrid", "w:vanish",
                 "w:webHidden", "w:color", "w:spacing", "w:w", "w:kern", "w:position",
                 "w:sz", "w:szCs", "w:highlight", "w:u", "w:effect", "w:bdr", "w:shd",
                 "w:fitText", "w:vertAlign", "w:rtl", "w:cs", "w:em", "w:lang",
                 "w:eastAsianLayout", "w:specVanish", "w:oMath"]
    PPR_ORDER = ["w:pStyle", "w:keepNext", "w:keepLines", "w:pageBreakBefore", "w:framePr",
                 "w:widowControl", "w:numPr", "w:suppressLineNumbers", "w:pBdr", "w:shd",
                 "w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap", "w:overflowPunct",
                 "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN", "w:bidi", "w:adjustRightInd",
                 "w:snapToGrid", "w:spacing", "w:ind", "w:contextualSpacing", "w:mirrorIndents",
                 "w:suppressOverlap", "w:jc", "w:textDirection", "w:textAlignment",
                 "w:textboxTightWrap", "w:outlineLvl", "w:divId", "w:cnfStyle", "w:rPr",
                 "w:sectPr", "w:pPrChange"]

    def insert_ordered(parent, child, order):
        """Insert `child` into `parent` at the schema-correct position (replacing any same-tag element)."""
        names = [qn(n) for n in order]
        my_pos = names.index(child.tag)
        for existing in parent.findall(child.tag):
            parent.remove(existing)
        for el in list(parent):
            if el.tag in names and names.index(el.tag) > my_pos:
                el.addprevious(child)
                return child
        parent.append(child)
        return child

    def shade(cell, fill):
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), fill)
        insert_ordered(cell._tc.get_or_add_tcPr(), shd, TCPR_ORDER)

    def cell_margins(cell, top=0, bottom=0, left=0, right=0):
        """Margins in twentieths of a point (dxa)."""
        mar = OxmlElement("w:tcMar")
        for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
            el = OxmlElement("w:" + k)
            el.set(qn("w:w"), str(int(v)))
            el.set(qn("w:type"), "dxa")
            mar.append(el)
        insert_ordered(cell._tc.get_or_add_tcPr(), mar, TCPR_ORDER)

    def cell_borders(cell, **edges):
        """edges: top/bottom/left/right = (size in 1/8 pt, hex colour) or None for no border."""
        b = OxmlElement("w:tcBorders")
        for edge in ("top", "left", "bottom", "right"):
            if edge not in edges:
                continue
            el = OxmlElement("w:" + edge)
            spec = edges[edge]
            if spec is None:
                el.set(qn("w:val"), "nil")
            else:
                sz, color = spec
                el.set(qn("w:val"), "single")
                el.set(qn("w:sz"), str(sz))
                el.set(qn("w:space"), "0")
                el.set(qn("w:color"), color)
            b.append(el)
        insert_ordered(cell._tc.get_or_add_tcPr(), b, TCPR_ORDER)

    def table_setup(table, widths_mm, align=None):
        """No borders, fixed layout, explicit column widths, flush with the margin."""
        tblPr = table._tbl.tblPr
        if align is not None:
            table.alignment = align
        b = OxmlElement("w:tblBorders")
        for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
            el = OxmlElement("w:" + edge)
            el.set(qn("w:val"), "nil")
            b.append(el)
        insert_ordered(tblPr, b, TBLPR_ORDER)
        if align is None:
            ind = OxmlElement("w:tblInd")
            ind.set(qn("w:w"), "0")
            ind.set(qn("w:type"), "dxa")
            insert_ordered(tblPr, ind, TBLPR_ORDER)
        layout = OxmlElement("w:tblLayout")
        layout.set(qn("w:type"), "fixed")
        insert_ordered(tblPr, layout, TBLPR_ORDER)
        mar = OxmlElement("w:tblCellMar")
        for k in ("top", "left", "bottom", "right"):
            el = OxmlElement("w:" + k)
            el.set(qn("w:w"), "0")
            el.set(qn("w:type"), "dxa")
            mar.append(el)
        insert_ordered(tblPr, mar, TBLPR_ORDER)
        table.autofit = False
        for row in table.rows:
            for i, w in enumerate(widths_mm):
                row.cells[i].width = Mm(w)
        for i, gc in enumerate(table._tbl.tblGrid.findall(qn("w:gridCol"))):
            gc.set(qn("w:w"), str(int(Mm(widths_mm[i]).twips)))

    def run(p, text, size=10, bold=False, italic=False, color=DARK, font="Arial", spacing=None):
        r = p.add_run(text)
        r.font.name = font
        r._element.rPr.rFonts.set(qn("w:eastAsia"), font)
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.italic = italic
        r.font.color.rgb = RGBColor.from_string(color)
        if spacing is not None:
            sp = OxmlElement("w:spacing")
            sp.set(qn("w:val"), str(int(spacing * 20)))  # points -> twentieths of a point
            insert_ordered(r._element.rPr, sp, RPR_ORDER)
        return r

    def para(container, text="", size=10, bold=False, italic=False, color=DARK, font="Arial",
             align=None, before=0, after=0, spacing=None):
        p = container.add_paragraph()
        p.paragraph_format.space_before = Pt(before)
        p.paragraph_format.space_after = Pt(after)
        if align is not None:
            p.alignment = align
        if text:
            run(p, text, size, bold, italic, color, font, spacing)
        return p

    def fill_first(cell, text="", **kw):
        """Use the cell's built-in first paragraph instead of adding a new (blank) one."""
        p = cell.paragraphs[0]
        p.paragraph_format.space_before = Pt(kw.pop("before", 0))
        p.paragraph_format.space_after = Pt(kw.pop("after", 0))
        align = kw.pop("align", None)
        if align is not None:
            p.alignment = align
        if text:
            run(p, text, **kw)
        return p

    def heading(container, text, after=3, first=False):
        if first:
            return fill_first(container, text, size=8.5, bold=True, color=BLACK, spacing=1.2, after=after)
        return para(container, text, size=8.5, bold=True, color=BLACK, spacing=1.2, after=after)

    def spacer(mm_):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = Pt(max(1, mm_ * 2.835))
        r = p.add_run(" ")
        r.font.size = Pt(1)
        return p

    # --------------------------------------------------------------- document
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.left_margin = sec.right_margin = Mm(15)
    sec.top_margin = Mm(12)
    sec.bottom_margin = Mm(16)
    sec.footer_distance = Mm(7)

    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(10)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.space_before = Pt(0)

    c = DATA["company"]
    R, L, CEN = WD_ALIGN_PARAGRAPH.RIGHT, WD_ALIGN_PARAGRAPH.LEFT, WD_ALIGN_PARAGRAPH.CENTER

    # ---- Header band (black) -------------------------------------------------
    # Remove the document's initial empty paragraph so the band sits at the top margin
    hdr = doc.add_table(rows=1, cols=2)
    table_setup(hdr, [90, 90])
    left, right = hdr.rows[0].cells
    for cell in (left, right):
        shade(cell, BLACK)
        cell_margins(cell, top=140, bottom=140, left=200, right=200)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    left.paragraphs[0].add_run().add_picture(LOGO, height=Mm(20))
    fill_first(right, "INVOICE", size=28, bold=True, color=WHITE, font="Times New Roman", spacing=2, align=R)
    for label, value in DATA["meta"]:
        p = para(right, align=R, before=1)
        run(p, f"{label}:  ", size=8.5, color="BBBBBB")
        run(p, value, size=9, bold=True, color=WHITE)
    body = doc.element.body
    first_p = body.find(qn("w:p"))
    if first_p is not None and first_p.getprevious() is None and not first_p.xpath(".//w:t"):
        body.remove(first_p)

    # ---- From / Bill To ------------------------------------------------------
    spacer(4)
    ft = doc.add_table(rows=1, cols=2)
    table_setup(ft, [90, 90])
    fcell, bcell = ft.rows[0].cells
    for cell in (fcell, bcell):
        cell_margins(cell, right=200)

    heading(fcell, "FROM", first=True)
    para(fcell, c["name"], size=13, bold=True, color=BLACK, font="Times New Roman")
    para(fcell, c["tagline"], size=7.5, color=GREY, spacing=1.5, after=3)
    for line in (c["address"], c["phone"], c["email"]):
        para(fcell, line, size=9.5, color=DARK)

    heading(bcell, "BILL TO", first=True)
    for i, line in enumerate(DATA["bill_to"]):
        para(bcell, line, size=11 if i == 0 else 9.5, bold=(i == 0), color=BLACK if i == 0 else DARK)

    # ---- Vehicle details -----------------------------------------------------
    spacer(5)
    heading(doc, "VEHICLE DETAILS")
    vt = doc.add_table(rows=2, cols=3)
    table_setup(vt, [60, 60, 60])
    for i, (label, value) in enumerate(DATA["vehicle"]):
        cell = vt.rows[i // 3].cells[i % 3]
        shade(cell, LIGHT)
        cell_margins(cell, top=80, bottom=80, left=140, right=140)
        cell_borders(cell, top=(6, WHITE), bottom=(6, WHITE), left=(6, WHITE), right=(6, WHITE))
        fill_first(cell, label.upper(), size=7, bold=True, color=GREY, spacing=0.6, after=1)
        para(cell, value, size=9.5, bold=True, color=BLACK)

    # ---- Line items ----------------------------------------------------------
    spacer(5)
    it = doc.add_table(rows=1, cols=5)
    table_setup(it, W_ITEMS)
    heads = ["#", "DESCRIPTION", "QTY", "UNIT PRICE", "AMOUNT"]
    aligns = [CEN, L, CEN, R, R]
    for i, h in enumerate(heads):
        cell = it.rows[0].cells[i]
        shade(cell, BLACK)
        cell_margins(cell, top=90, bottom=90, left=100, right=100)
        fill_first(cell, h, size=8, bold=True, color=WHITE, spacing=0.8, align=aligns[i])
    rows_data = [(str(n), d, q, u, a) for n, (d, q, u, a) in enumerate(DATA["items"], start=1)]
    rows_data.append((" ", " ", " ", " ", " "))  # one blank row for hand additions
    for vals in rows_data:
        row = it.add_row()
        for i, v in enumerate(vals):
            cell = row.cells[i]
            cell.width = Mm(W_ITEMS[i])
            cell_margins(cell, top=100, bottom=100, left=100, right=100)
            cell_borders(cell, bottom=(4, RULE))
            fill_first(cell, v, size=9.5, color=GREY if i == 0 else DARK, align=aligns[i])

    # ---- Payment details (left)  |  Totals (right) ---------------------------
    spacer(4)
    pt = doc.add_table(rows=1, cols=2)
    table_setup(pt, W_PAY_TOT)
    pc, tc = pt.rows[0].cells
    cell_margins(pc, right=300, top=40)
    cell_margins(tc)
    heading(pc, "PAYMENT DETAILS", first=True, after=4)
    for label, value in DATA["payment"]:
        para(pc, label, size=7.5, color=GREY, spacing=0.4)
        para(pc, value, size=9.5, bold=True, color=BLACK, after=4)

    # nested totals table, flush right inside the right-hand cell
    tt = tc.add_table(rows=0, cols=2)
    table_setup(tt, W_TOTALS, align=WD_TABLE_ALIGNMENT.RIGHT)
    for label, value, strong in DATA["totals"]:
        row = tt.add_row()
        lc, vc = row.cells
        lc.width, vc.width = Mm(W_TOTALS[0]), Mm(W_TOTALS[1])
        pad = 90 if strong else 65
        for cell in (lc, vc):
            cell_margins(cell, top=pad, bottom=pad, left=120, right=100)
            if strong:
                shade(cell, BLACK if label == "BALANCE DUE" else LIGHT)
            else:
                cell_borders(cell, bottom=(4, RULE))
        col = WHITE if label == "BALANCE DUE" else BLACK
        fill_first(lc, label, size=10 if strong else 9.5, bold=strong, color=col if strong else GREY, align=R)
        fill_first(vc, value, size=11 if strong else 9.5, bold=strong, color=col if strong else DARK, align=R)
    # remove the empty paragraph Word requires before a nested table, shrink the trailing one
    tc.paragraphs[0]._p.getparent().remove(tc.paragraphs[0]._p)
    tail = tc.paragraphs[-1]
    tail.paragraph_format.line_spacing = Pt(1)
    tail.add_run(" ").font.size = Pt(1)

    # ---- Terms & conditions --------------------------------------------------
    spacer(5)
    heading(doc, "TERMS & CONDITIONS", after=3)
    for i, t in enumerate(DATA["terms"], start=1):
        p = para(doc, after=2)
        p.paragraph_format.left_indent = Mm(5)
        p.paragraph_format.first_line_indent = Mm(-5)
        run(p, f"{i}.  ", size=8.5, bold=True, color=BLACK)
        run(p, t, size=8.5, color=DARK)

    # ---- Signatures ----------------------------------------------------------
    spacer(7)
    st = doc.add_table(rows=1, cols=3)
    table_setup(st, W_SIG)
    s1, _, s2 = st.rows[0].cells
    for cell, who in ((s1, "Authorized Signature \u2013 MAI AUTOS"), (s2, "Customer Signature")):
        fill_first(cell, "_" * 34, size=9, color=BLACK, before=10)
        para(cell, who, size=8, bold=True, color=BLACK, before=3)
        para(cell, "Name:  ______________________     Date:  ____________", size=8, color=GREY, before=3)

    # ---- Thank you -----------------------------------------------------------
    para(doc, DATA["thanks"], size=10.5, italic=True, color=BLACK, font="Times New Roman", align=CEN, before=12)

    # ---- Footer --------------------------------------------------------------
    fp = sec.footer.paragraphs[0]
    fp.alignment = CEN
    pPr = fp._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    top = OxmlElement("w:top")
    top.set(qn("w:val"), "single"); top.set(qn("w:sz"), "4"); top.set(qn("w:space"), "6"); top.set(qn("w:color"), RULE)
    pbdr.append(top)
    insert_ordered(pPr, pbdr, PPR_ORDER)
    run(fp, f"{c['name']}  \u00b7  {c['tagline'].title()}  \u00b7  {c['address']}  \u00b7  {c['phone']}  \u00b7  {c['email']}",
        size=7.5, color=GREY)

    doc.core_properties.title = "MAI AUTOS - Invoice"
    doc.core_properties.author = "MAI AUTOS"
    doc.save(path)


# ============================================================================
# PDF (reportlab)
# ============================================================================
def build_pdf(path):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether, PageTemplate,
                                    Paragraph, Spacer, Table, TableStyle)

    C = lambda h: colors.HexColor("#" + h)
    c = DATA["company"]
    W = W_TOTAL * mm

    def S(name, **kw):
        base = dict(fontName="Helvetica", fontSize=10, leading=13, textColor=C(DARK))
        base.update(kw)
        return ParagraphStyle(name, **base)

    st_label = S("label", fontSize=7, leading=9, textColor=C(GREY))
    st_head = S("head", fontName="Helvetica-Bold", fontSize=8.5, leading=11, textColor=C(BLACK))
    st_body = S("body", fontSize=9.5, leading=13)
    st_body_b = S("bodyb", fontName="Helvetica-Bold", fontSize=9.5, leading=13, textColor=C(BLACK))
    NOPAD = [("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
             ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]

    story = []

    # ---- Header band ---------------------------------------------------------
    logo_h = 20 * mm
    logo = Image(LOGO, width=logo_h * LOGO_RATIO, height=logo_h)
    logo.hAlign = "LEFT"
    right_lines = [Paragraph("INVOICE", S("inv", fontName="Times-Bold", fontSize=28, leading=32,
                                          textColor=colors.white, alignment=TA_RIGHT))]
    for label, value in DATA["meta"]:
        right_lines.append(Paragraph(
            f'<font size="8.5" color="#BBBBBB">{label}:&nbsp;&nbsp;</font>'
            f'<font size="9" color="#FFFFFF"><b>{value}</b></font>',
            S("meta", alignment=TA_RIGHT, leading=12)))
    hdr = Table([[logo, right_lines]], colWidths=[W / 2, W / 2])
    hdr.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.black),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    story += [hdr, Spacer(1, 4 * mm)]

    # ---- From / Bill To ------------------------------------------------------
    from_block = [
        Paragraph("FROM", st_head), Spacer(1, 3),
        Paragraph(c["name"], S("cn", fontName="Times-Bold", fontSize=13, leading=16, textColor=C(BLACK))),
        Paragraph(c["tagline"], S("tag", fontSize=7.5, leading=10, textColor=C(GREY))), Spacer(1, 3),
        Paragraph(c["address"], st_body), Paragraph(c["phone"], st_body), Paragraph(c["email"], st_body),
    ]
    bill_block = [Paragraph("BILL TO", st_head), Spacer(1, 3)]
    for i, line in enumerate(DATA["bill_to"]):
        bill_block.append(Paragraph(line, S("b1", fontName="Helvetica-Bold", fontSize=11, leading=14,
                                                 textColor=C(BLACK)) if i == 0 else st_body))
    fb = Table([[from_block, bill_block]], colWidths=[W / 2, W / 2])
    fb.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")] + NOPAD))
    story += [fb, Spacer(1, 5 * mm)]

    # ---- Vehicle details -----------------------------------------------------
    story += [Paragraph("VEHICLE DETAILS", st_head), Spacer(1, 3)]
    cells = [[Paragraph(label.upper(), st_label), Paragraph(value, st_body_b)] for label, value in DATA["vehicle"]]
    vt = Table([cells[0:3], cells[3:6]], colWidths=[W / 3] * 3)
    vt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), C(LIGHT)),
        ("GRID", (0, 0), (-1, -1), 1.5, colors.white),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story += [vt, Spacer(1, 5 * mm)]

    # ---- Line items ----------------------------------------------------------
    hstyle = S("th", fontName="Helvetica-Bold", fontSize=8, leading=10, textColor=colors.white)
    heads = ["#", "DESCRIPTION", "QTY", "UNIT PRICE", "AMOUNT"]
    al = [TA_CENTER, TA_LEFT, TA_CENTER, TA_RIGHT, TA_RIGHT]
    data = [[Paragraph(h, ParagraphStyle("h%d" % i, parent=hstyle, alignment=al[i])) for i, h in enumerate(heads)]]
    for n, (desc, qty, unit, amt) in enumerate(DATA["items"], start=1):
        vals = [str(n), desc, qty, unit, amt]
        data.append([Paragraph(v, ParagraphStyle("c%d" % i, parent=st_body, alignment=al[i],
                                                 textColor=C(GREY) if i == 0 else C(DARK)))
                     for i, v in enumerate(vals)])
    data.append([Paragraph("&nbsp;", st_body)] * 5)
    it = Table(data, colWidths=[w * mm for w in W_ITEMS], repeatRows=1)
    it.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.black),
        ("LINEBELOW", (0, 1), (-1, -1), 0.5, C(RULE)),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, 0), 5), ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
        ("TOPPADDING", (0, 1), (-1, -1), 5), ("BOTTOMPADDING", (0, 1), (-1, -1), 5),
    ]))
    story += [it, Spacer(1, 4 * mm)]

    # ---- Payment details (left) | Totals (right) -----------------------------
    pay = [Paragraph("PAYMENT DETAILS", st_head), Spacer(1, 4)]
    for label, value in DATA["payment"]:
        pay += [Paragraph(label, st_label), Paragraph(value, st_body_b), Spacer(1, 4)]

    tdata, tstyle = [], [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5),
    ]
    for r, (label, value, strong) in enumerate(DATA["totals"]):
        if strong:
            fill = colors.black if label == "BALANCE DUE" else C(LIGHT)
            col = colors.white if label == "BALANCE DUE" else C(BLACK)
            tdata.append([Paragraph(label, S("tl", fontName="Helvetica-Bold", fontSize=10, alignment=TA_RIGHT, textColor=col)),
                          Paragraph(value, S("tv", fontName="Helvetica-Bold", fontSize=11, alignment=TA_RIGHT, textColor=col))])
            tstyle += [("BACKGROUND", (0, r), (-1, r), fill),
                       ("TOPPADDING", (0, r), (-1, r), 5), ("BOTTOMPADDING", (0, r), (-1, r), 5)]
        else:
            tdata.append([Paragraph(label, S("tl2", fontSize=9.5, alignment=TA_RIGHT, textColor=C(GREY))),
                          Paragraph(value, S("tv2", fontSize=9.5, alignment=TA_RIGHT))])
            tstyle.append(("LINEBELOW", (0, r), (-1, r), 0.5, C(RULE)))
    tt = Table(tdata, colWidths=[w * mm for w in W_TOTALS], hAlign="RIGHT")
    tt.setStyle(TableStyle(tstyle))

    pt = Table([[pay, tt]], colWidths=[w * mm for w in W_PAY_TOT])
    pt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                            ("TOPPADDING", (0, 0), (0, 0), 2)] + NOPAD[:2] + NOPAD[3:]))
    story += [pt, Spacer(1, 5 * mm)]

    # ---- Terms & conditions --------------------------------------------------
    terms = [Paragraph("TERMS &amp; CONDITIONS", st_head), Spacer(1, 3)]
    for i, t in enumerate(DATA["terms"], start=1):
        terms.append(Paragraph(f"<b>{i}.</b>&nbsp;&nbsp;{t}", S("term", fontSize=8.5, leading=11.5,
                                                                 leftIndent=14, firstLineIndent=-14, spaceAfter=2)))
    story += terms + [Spacer(1, 7 * mm)]

    # ---- Signatures ----------------------------------------------------------
    def sig(who):
        return [Paragraph("_" * 38, S("sl", fontSize=9, textColor=C(BLACK))),
                Spacer(1, 3),
                Paragraph(who, S("sw", fontName="Helvetica-Bold", fontSize=8, leading=10, textColor=C(BLACK))),
                Spacer(1, 3),
                Paragraph("Name:  ______________________ &nbsp;&nbsp;&nbsp; Date:  ____________",
                          S("sn", fontSize=8, leading=10, textColor=C(GREY)))]
    sg = Table([[sig("Authorized Signature \u2013 MAI AUTOS"), "", sig("Customer Signature")]],
               colWidths=[w * mm for w in W_SIG])
    sg.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")] + NOPAD))
    story += [KeepTogether([sg, Spacer(1, 7 * mm),
                            Paragraph(DATA["thanks"], S("thx", fontName="Times-Italic", fontSize=10.5,
                                                        alignment=TA_CENTER, textColor=C(BLACK)))])]

    # ---- Page footer ---------------------------------------------------------
    def on_page(canv, doc_):
        canv.saveState()
        x0, x1, y = 15 * mm, 195 * mm, 11 * mm
        canv.setStrokeColor(C(RULE)); canv.setLineWidth(0.5)
        canv.line(x0, y + 4 * mm, x1, y + 4 * mm)
        canv.setFont("Helvetica", 7.5); canv.setFillColor(C(GREY))
        canv.drawCentredString(105 * mm, y,
                               f"{c['name']}  \u00b7  {c['tagline'].title()}  \u00b7  {c['address']}  \u00b7  {c['phone']}  \u00b7  {c['email']}")
        canv.restoreState()

    doc = BaseDocTemplate(path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                          topMargin=12 * mm, bottomMargin=17 * mm,
                          title="MAI AUTOS - Invoice", author="MAI AUTOS", subject="Invoice")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height,
                  leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id="main")
    doc.addPageTemplates([PageTemplate(id="page", frames=[frame], onPage=on_page)])
    doc.build(story)


if __name__ == "__main__":
    build_docx("/home/user/MAI_AUTOS_Invoice_Template.docx")
    build_pdf("/home/user/MAI_AUTOS_Invoice_Template.pdf")
    print("done")
